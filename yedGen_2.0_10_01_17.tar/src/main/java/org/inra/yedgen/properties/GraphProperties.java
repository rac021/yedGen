
package org.inra.yedgen.properties;

/**
 *
 * @author ryahiaoui
 */
public class GraphProperties {
    
}
